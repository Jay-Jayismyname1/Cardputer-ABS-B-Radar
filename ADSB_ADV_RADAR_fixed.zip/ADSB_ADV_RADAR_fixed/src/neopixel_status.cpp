#include "neopixel_status.h"
#include "config.h"
#include <Adafruit_NeoPixel.h>
#include <Preferences.h>

namespace NeopixelStatus {

namespace {
    Adafruit_NeoPixel pixel(Config::NEOPIXEL_COUNT, Config::NEOPIXEL_PIN,
                             NEO_GRB + NEO_KHZ800);
    Preferences prefs;

    constexpr uint32_t IDLE_OFF    = 0x000000;
    constexpr uint32_t BLUE_COLOR  = 0x0000FF;
    constexpr uint32_t YELLOW_COLOR= 0xFFFF00;
    constexpr uint32_t AMBER_COLOR = 0xFFB000;
    constexpr uint32_t GREEN_COLOR = 0x00FF00;

    uint8_t brightnessPercent = 60;

    uint32_t baseColor = IDLE_OFF;
    bool flashing = false;       // whether the current zone wants a flash
    bool flashOn = false;        // current flash phase
    uint32_t lastFlashToggleMs = 0;
    bool risingEdgeThisTick = false;

    void applyPixel(uint32_t color) {
        pixel.setPixelColor(0, color);
        pixel.show();
    }
}

void init() {
    prefs.begin("adsb_radar", false);
    brightnessPercent = prefs.getUChar("ledBright", 60);

    pixel.begin();
    pixel.setBrightness((brightnessPercent * 255) / 100);
    pixel.show(); // off by default until first update()
}

void setOff() {
    baseColor = IDLE_OFF;
    flashing = false;
    flashOn = false;
    applyPixel(IDLE_OFF);
}

void update(const Aircraft* table, uint8_t count, int selectedIndex) {
    bool any = false;
    float closestKm = 1e9f;

    if (selectedIndex >= 0 && selectedIndex < count && table[selectedIndex].valid) {
        any = true;
        closestKm = table[selectedIndex].distanceKm;
    } else {
        for (uint8_t i = 0; i < count; i++) {
            if (!table[i].valid) continue;
            any = true;
            if (table[i].distanceKm < closestKm) closestKm = table[i].distanceKm;
        }
    }

    if (!any) {
        baseColor = IDLE_OFF;
        flashing = false;
    } else if (closestKm <= Config::ZONE_VISUAL_KM) {
        baseColor = GREEN_COLOR;
        flashing = true;
    } else if (closestKm <= Config::ZONE_AMBER_KM) {
        baseColor = AMBER_COLOR;
        flashing = false;
    } else if (closestKm <= Config::ZONE_YELLOW_KM) {
        baseColor = YELLOW_COLOR;
        flashing = false;
    } else if (closestKm <= Config::ZONE_BLUE_KM) {
        baseColor = BLUE_COLOR;
        flashing = false;
    } else {
        baseColor = IDLE_OFF;
        flashing = false;
    }

    if (!flashing) {
        flashOn = false;
        applyPixel(baseColor);
    }

}

void tick(uint32_t now) {
    risingEdgeThisTick = false;

    if (!flashing) return;

    if (now - lastFlashToggleMs >= Config::FLASH_INTERVAL_MS) {
        lastFlashToggleMs = now;
        bool wasOn = flashOn;
        flashOn = !flashOn;
        applyPixel(flashOn ? baseColor : IDLE_OFF);
        if (!wasOn && flashOn) risingEdgeThisTick = true;
    }
}

bool isFlashRisingEdge() {
    return risingEdgeThisTick;
}

void setBrightnessPercent(uint8_t percent) {
    if (percent > 100) percent = 100;
    brightnessPercent = percent;
    prefs.putUChar("ledBright", brightnessPercent);
    pixel.setBrightness((brightnessPercent * 255) / 100);
    applyPixel(flashing ? (flashOn ? baseColor : IDLE_OFF) : baseColor);
}

uint8_t getBrightnessPercent() {
    return brightnessPercent;
}

}
