#include "display_radar.h"
#include "radar_math.h"
#include "config.h"
#include <M5Cardputer.h>

namespace DisplayRadar {

namespace {
    M5Canvas radarSprite(&M5Cardputer.Display);
    int16_t centerX, centerY, outerRadiusPx;
    float sweepAngleDeg = 0.0f;
    constexpr float SWEEP_DEGREES_PER_SEC = 90.0f;

    uint8_t rangeIndex = Config::DEFAULT_RANGE_INDEX;

    uint16_t altitudeColor(int32_t altFt) {
        if (altFt < Config::COLOR_LOW_ALT_THRESHOLD_FT) return TFT_YELLOW;
        if (altFt < Config::COLOR_MID_ALT_THRESHOLD_FT) return TFT_GREEN;
        return TFT_CYAN;
    }

    void drawRadarBase() {
        radarSprite.fillScreen(TFT_BLACK);

 
        for (int i = 1; i <= 3; i++) {
            radarSprite.drawCircle(centerX, centerY, (outerRadiusPx * i) / 3, TFT_DARKGREEN);
        }

        radarSprite.drawFastHLine(centerX - outerRadiusPx, centerY, outerRadiusPx * 2, TFT_DARKGREEN);
        radarSprite.drawFastVLine(centerX, centerY - outerRadiusPx, outerRadiusPx * 2, TFT_DARKGREEN);


        radarSprite.setTextColor(TFT_DARKGREEN);
        radarSprite.setTextDatum(middle_center);
        radarSprite.drawString("N", centerX, centerY - outerRadiusPx - 8);
        radarSprite.drawString("S", centerX, centerY + outerRadiusPx + 8);
        radarSprite.drawString("E", centerX + outerRadiusPx + 8, centerY);
        radarSprite.drawString("W", centerX - outerRadiusPx - 8, centerY);
    }

    void drawSweep() {
        double rad = sweepAngleDeg * DEG_TO_RAD;
        int16_t x2 = centerX + outerRadiusPx * sin(rad);
        int16_t y2 = centerY - outerRadiusPx * cos(rad);
        radarSprite.drawLine(centerX, centerY, x2, y2, TFT_GREEN);
        for (int i = 1; i <= 3; i++) {
            double trailRad = (sweepAngleDeg - i * 6.0) * DEG_TO_RAD;
            int16_t tx = centerX + outerRadiusPx * sin(trailRad);
            int16_t ty = centerY - outerRadiusPx * cos(trailRad);
            radarSprite.drawLine(centerX, centerY, tx, ty, 0x0320 /* dim green */);
        }
    }

    void drawAircraftBlip(const Aircraft& a, bool selected) {
        RadarMath::PolarCoord polar{a.distanceKm, a.bearingDeg};
        auto pt = RadarMath::toScreen(polar, centerX, centerY, outerRadiusPx,
                                       Config::RANGE_STEPS_KM[rangeIndex]);

        uint16_t color = altitudeColor(a.altBaroFt);
        radarSprite.fillCircle(pt.x, pt.y, selected ? 4 : 3, color);
        if (selected) {
            radarSprite.drawCircle(pt.x, pt.y, 7, TFT_WHITE);
        }

        // Callsign label — small, offset above the blip
        radarSprite.setTextColor(color);
        radarSprite.setTextDatum(bottom_center);
        radarSprite.setTextSize(1);
        const char* label = a.callsign[0] ? a.callsign : a.hex;
        radarSprite.drawString(label, pt.x, pt.y - 6);
    }

    void drawHudPanel(const Aircraft* list, uint8_t count, uint8_t selectedIndex,
                       const char* wifiStatusText, int batteryPct,
                       const char* locationLabel, int lastHttpCode) {
        // Bottom strip: detail on the closest / selected aircraft
        int16_t panelY = M5Cardputer.Display.height() - 42;
        radarSprite.fillRect(0, panelY, M5Cardputer.Display.width(), 42, TFT_BLACK);
        radarSprite.drawFastHLine(0, panelY, M5Cardputer.Display.width(), TFT_DARKGREEN);

        radarSprite.setTextDatum(top_left);
        radarSprite.setTextColor(TFT_WHITE);

        if (count == 0 || selectedIndex >= count) {
            radarSprite.drawString("No traffic in range", 4, panelY + 4);
        } else {
            const Aircraft& a = list[selectedIndex];
            char line1[64];
            snprintf(line1, sizeof(line1), "%s  %s  %s",
                     a.callsign[0] ? a.callsign : "-------",
                     a.reg[0] ? a.reg : "REG?",
                     a.airlineName[0] ? a.airlineName : "");
            radarSprite.drawString(line1, 4, panelY + 4);

            char line2[64];
            snprintf(line2, sizeof(line2), "%.0fkm  ALT %ldft  VS %+dfpm  HDG %03.0f",
                     a.distanceKm, (long)a.altBaroFt, a.vertRateFtMin, a.headingDeg);
            radarSprite.drawString(line2, 4, panelY + 16);

            char line3[64];
            if (a.estSeats > 0) {
                snprintf(line3, sizeof(line3), "%s  ~%u seats (est.)",
                         a.typeCode[0] ? a.typeCode : "TYPE?", a.estSeats);
            } else {
                snprintf(line3, sizeof(line3), "%s  seats: n/a",
                         a.typeCode[0] ? a.typeCode : "TYPE?");
            }
            radarSprite.drawString(line3, 4, panelY + 28);
        }

        // Top-right status: wifi + battery + range + count
        char status[64];
        snprintf(status, sizeof(status), "%s  %s  %d%%  %.0fkm  [%u]  h%d",
                 wifiStatusText, locationLabel, batteryPct,
                 Config::RANGE_STEPS_KM[rangeIndex], count, lastHttpCode);
        radarSprite.setTextDatum(top_right);
        radarSprite.drawString(status, M5Cardputer.Display.width() - 4, 4);
    }
}

void init() {
    centerX = M5Cardputer.Display.width() / 2;
    centerY = (M5Cardputer.Display.height() - 42) / 2; // leave room for HUD strip at bottom
    outerRadiusPx = min(centerX, centerY) - 14;
    radarSprite.createSprite(M5Cardputer.Display.width(), M5Cardputer.Display.height());
    radarSprite.setTextFont(1);
}

void tickSweep(uint32_t deltaMs) {
    sweepAngleDeg += SWEEP_DEGREES_PER_SEC * (deltaMs / 1000.0f);
    if (sweepAngleDeg >= 360.0f) sweepAngleDeg -= 360.0f;
}

void cycleRange() {
    rangeIndex = (rangeIndex + 1) % Config::RANGE_STEP_COUNT;
}

float currentRangeKm() {
    return Config::RANGE_STEPS_KM[rangeIndex];
}

void render(const Aircraft* aircraftList, uint8_t count,
            float rangeKm, uint8_t selectedIndex,
            const char* wifiStatusText, int batteryPct,
            const char* locationLabel, int lastHttpCode) {
    drawRadarBase();
    drawSweep();

    for (uint8_t i = 0; i < count; i++) {
        if (!aircraftList[i].valid) continue;
        drawAircraftBlip(aircraftList[i], i == selectedIndex);
    }

    drawHudPanel(aircraftList, count, selectedIndex, wifiStatusText, batteryPct,
                 locationLabel, lastHttpCode);

    radarSprite.pushSprite(0, 0);
}

}
