#include "settings_menu.h"
#include "wifi_setup_screen.h"
#include "wifi_manager.h"
#include "volume_control.h"
#include "neopixel_status.h"
#include "location_manager.h"
#include "config.h"
#include <M5Cardputer.h>
#include <Preferences.h>

namespace SettingsMenu {

namespace {
    constexpr uint8_t HID_ENTER = 0x28;
    constexpr uint8_t HID_ESC   = 0x29; // physical Esc key — kept working alongside '`'
    constexpr uint8_t HID_BACKSPACE = 0x2A; // physical "Del" key
    constexpr uint16_t TONE_NAV_HZ     = 1400;
    constexpr uint16_t TONE_NAV_MS     = 25;
    constexpr uint16_t TONE_ADJUST_HZ  = 1000;
    constexpr uint16_t TONE_ADJUST_MS  = 25;
    constexpr uint16_t TONE_CONFIRM_HZ = 2000;
    constexpr uint16_t TONE_CONFIRM_MS = 45;
    constexpr uint16_t TONE_CLOSE_HZ   = 700;
    constexpr uint16_t TONE_CLOSE_MS   = 45;

    void tone(uint16_t hz, uint16_t ms) { M5Cardputer.Speaker.tone(hz, ms); }

    enum class Item : uint8_t { Wifi = 0, Location, DisplayBrightness, LedBrightness, Volume, Count };
    Item selected = Item::Wifi;

    bool inWifiSubscreen = false;
    bool inManualLocationEntry = false;
    uint8_t manualEntryField = 0; // 0 = lat, 1 = lon
    char manualLatBuf[16] = "";
    char manualLonBuf[16] = "";
    uint8_t manualLatLen = 0;
    uint8_t manualLonLen = 0;
    bool done = false;

    Preferences prefs;
    uint8_t displayBrightnessPercent = 80;
    M5Canvas settingsSprite(&M5Cardputer.Display);
    bool spriteReady = false;

    const char* itemName(Item i) {
        switch (i) {
            case Item::Wifi:              return "WiFi";
            case Item::Location:          return "Location";
            case Item::DisplayBrightness: return "Display Brightness";
            case Item::LedBrightness:     return "LED Brightness";
            case Item::Volume:            return "Volume";
            default:                       return "";
        }
    }

    void applyDisplayBrightness() {
        M5Cardputer.Display.setBrightness((displayBrightnessPercent * 255) / 100);
    }

    void startManualEntry() {
        double lat = 0.0, lon = 0.0;
        LocationManager::getHomeLocation(lat, lon);
        if (lat != 0.0 || lon != 0.0) {
            manualLatLen = snprintf(manualLatBuf, sizeof(manualLatBuf), "%.4f", lat);
            manualLonLen = snprintf(manualLonBuf, sizeof(manualLonBuf), "%.4f", lon);
        } else {
            manualLatBuf[0] = '\0'; manualLatLen = 0;
            manualLonBuf[0] = '\0'; manualLonLen = 0;
        }
        manualEntryField = 0;
        inManualLocationEntry = true;
    }
}

void init() {
    prefs.begin("adsb_radar", false);
    displayBrightnessPercent = prefs.getUChar("dispBright", 80);

    settingsSprite.createSprite(M5Cardputer.Display.width(), M5Cardputer.Display.height());
    settingsSprite.setTextFont(1);
    spriteReady = true;
}

void onEnter() {
    selected = Item::Wifi;
    inWifiSubscreen = false;
    inManualLocationEntry = false;
    done = false;
}

bool isDone() { return done; }

void handleWord(const char* chars, uint8_t count, bool fnHeld, bool shiftHeld,
                 const uint8_t* hidKeys, uint8_t hidKeyCount) {

    if (inManualLocationEntry) {
        char* buf = (manualEntryField == 0) ? manualLatBuf : manualLonBuf;
        uint8_t& len = (manualEntryField == 0) ? manualLatLen : manualLonLen;
        constexpr uint8_t bufCap = 16;

        bool hasEnter = false, hasEsc = false, hasBackspace = false;
        for (uint8_t i = 0; i < hidKeyCount; i++) {
            if (hidKeys[i] == HID_ENTER) hasEnter = true;
            if (hidKeys[i] == HID_ESC) hasEsc = true;
            if (hidKeys[i] == HID_BACKSPACE) hasBackspace = true;
        }
        bool hasBacktick = false;
        for (uint8_t i = 0; i < count; i++) if (chars[i] == '`') hasBacktick = true;

        if (hasEsc || hasBacktick) { // cancel, discard edits
            tone(TONE_CLOSE_HZ, TONE_CLOSE_MS);
            inManualLocationEntry = false;
            return;
        }

        if (hasBackspace) {
            if (len > 0) { len--; buf[len] = '\0'; tone(TONE_ADJUST_HZ, TONE_ADJUST_MS); }
            return;
        }

        if (hasEnter) {
            if (manualEntryField == 0) {
                manualEntryField = 1;
                tone(TONE_NAV_HZ, TONE_NAV_MS);
            } else {
                double lat = atof(manualLatBuf);
                double lon = atof(manualLonBuf);
                if ((lat != 0.0 || lon != 0.0) && lat >= -90.0 && lat <= 90.0 &&
                    lon >= -180.0 && lon <= 180.0) {
                    LocationManager::setManualLocation(lat, lon);
                    tone(TONE_CONFIRM_HZ, TONE_CONFIRM_MS);
                    inManualLocationEntry = false;
                } else {
                    // Invalid/empty — low buzz, stay in the field to fix it.
                    tone(TONE_CLOSE_HZ, TONE_CLOSE_MS);
                }
            }
            return;
        }

        for (uint8_t i = 0; i < count; i++) {
            char c = chars[i];
            bool allowed = (c >= '0' && c <= '9') || c == '-' || c == '.';
            if (allowed && len < bufCap - 1) {
                buf[len++] = c;
                buf[len] = '\0';
            }
        }
        return;
    }

    if (inWifiSubscreen) {
        WifiSetupScreen::handleWord(chars, count, fnHeld, shiftHeld, hidKeys, hidKeyCount);
        if (WifiSetupScreen::isDone()) {
            if (WifiSetupScreen::didConnectSucceed()) {
                WifiMgr::saveCredentialsToSdIfMounted();
            }
            inWifiSubscreen = false;
        }
        return;
    }

    bool hasEnter = false, hasEsc = false;
    for (uint8_t i = 0; i < hidKeyCount; i++) {
        if (hidKeys[i] == HID_ENTER) hasEnter = true;
        if (hidKeys[i] == HID_ESC) hasEsc = true;
    }
    bool hasBacktick = false;
    for (uint8_t i = 0; i < count; i++) {
        if (chars[i] == '`') hasBacktick = true;
    }

    if (hasEsc || hasBacktick) { tone(TONE_CLOSE_HZ, TONE_CLOSE_MS); done = true; return; }

    for (uint8_t i = 0; i < count; i++) {
        if (chars[i] == ';') { // up
            selected = static_cast<Item>((static_cast<uint8_t>(selected) +
                       static_cast<uint8_t>(Item::Count) - 1) % static_cast<uint8_t>(Item::Count));
            tone(TONE_NAV_HZ, TONE_NAV_MS);
        } else if (chars[i] == '.') { // down
            selected = static_cast<Item>((static_cast<uint8_t>(selected) + 1) %
                       static_cast<uint8_t>(Item::Count));
            tone(TONE_NAV_HZ, TONE_NAV_MS);
        } else if (chars[i] == '/') { // right — increase slider
            switch (selected) {
                case Item::Location:
                    if (LocationManager::isGpsEnabled()) LocationManager::cycleGpsPinPair();
                    break;
                case Item::DisplayBrightness:
                    displayBrightnessPercent = min(100, displayBrightnessPercent + 10);
                    prefs.putUChar("dispBright", displayBrightnessPercent);
                    applyDisplayBrightness();
                    break;
                case Item::LedBrightness:
                    NeopixelStatus::setBrightnessPercent(
                        min(100, NeopixelStatus::getBrightnessPercent() + 10));
                    break;
                case Item::Volume:
                    VolumeControl::increase();
                    break;
                default: break;
            }
            tone(TONE_ADJUST_HZ, TONE_ADJUST_MS);
        } else if (chars[i] == ',') { // left — decrease slider
            switch (selected) {
                case Item::Location:
                    if (LocationManager::isGpsEnabled()) LocationManager::cycleGpsPinPair();
                    break;
                case Item::DisplayBrightness:
                    displayBrightnessPercent = max(0, displayBrightnessPercent - 10);
                    prefs.putUChar("dispBright", displayBrightnessPercent);
                    applyDisplayBrightness();
                    break;
                case Item::LedBrightness:
                    NeopixelStatus::setBrightnessPercent(
                        max(0, NeopixelStatus::getBrightnessPercent() - 10));
                    break;
                case Item::Volume:
                    VolumeControl::decrease();
                    break;
                default: break;
            }
            tone(TONE_ADJUST_HZ, TONE_ADJUST_MS);
        } else if (chars[i] == 'm' && selected == Item::Location) {
            tone(TONE_CONFIRM_HZ, TONE_CONFIRM_MS);
            startManualEntry();
        }
    }

    if (hasEnter && selected == Item::Wifi) {
        tone(TONE_CONFIRM_HZ, TONE_CONFIRM_MS);
        inWifiSubscreen = true;
        WifiSetupScreen::onEnter();
    }
    if (hasEnter && selected == Item::Location) {
        tone(TONE_CONFIRM_HZ, TONE_CONFIRM_MS);
        LocationManager::setGpsEnabled(!LocationManager::isGpsEnabled());
    }
}

void render() {
    if (inWifiSubscreen) {
        WifiSetupScreen::render();
        return;
    }

    if (!spriteReady) return;

    auto& d = settingsSprite;

    if (inManualLocationEntry) {
        d.fillScreen(TFT_BLACK);
        d.setTextDatum(top_left);
        d.setTextColor(TFT_GREEN);
        d.setCursor(4, 4);
        d.println("Manual location  (` to cancel)");
        d.drawFastHLine(0, 20, d.width(), TFT_DARKGREEN);

        d.setCursor(4, 30);
        d.setTextColor(manualEntryField == 0 ? TFT_BLACK : TFT_WHITE,
                        manualEntryField == 0 ? TFT_GREEN : TFT_BLACK);
        d.printf(" Lat: %s%s \n", manualLatBuf, manualEntryField == 0 ? "_" : "");

        d.setCursor(4, 46);
        d.setTextColor(manualEntryField == 1 ? TFT_BLACK : TFT_WHITE,
                        manualEntryField == 1 ? TFT_GREEN : TFT_BLACK);
        d.printf(" Lon: %s%s \n", manualLonBuf, manualEntryField == 1 ? "_" : "");

        d.setTextColor(TFT_DARKGREEN, TFT_BLACK);
        d.setCursor(4, 66);
        d.println("Digits, - and . only");
        d.println("Enter: next field / confirm");
        d.println("Del: backspace  ` : cancel");

        d.pushSprite(0, 0);
        return;
    }

    d.fillScreen(TFT_BLACK);
    d.setTextDatum(top_left);
    d.setTextColor(TFT_GREEN);
    d.setCursor(4, 4);
    d.println("Settings  (` to close)");
    d.drawFastHLine(0, 20, d.width(), TFT_DARKGREEN);

    d.setCursor(4, 26);
    for (uint8_t i = 0; i < static_cast<uint8_t>(Item::Count); i++) {
        Item it = static_cast<Item>(i);
        bool isSelected = (it == selected);
        d.setTextColor(isSelected ? TFT_BLACK : TFT_WHITE, isSelected ? TFT_GREEN : TFT_BLACK);

        switch (it) {
            case Item::Wifi:
                d.printf("WiFi: %s\n", WifiMgr::getState() == WifiMgr::State::Connected
                                        ? "Connected" : "Not connected");
                break;
            case Item::Location:
                if (LocationManager::isGpsEnabled()) {
                    d.printf("GPS: ON (%s) %s\n", LocationManager::currentGpsPinLabel(),
                             LocationManager::hasGpsFix() ? "FIX" : "no fix");
                } else if (LocationManager::currentSource() == LocationManager::Source::None) {
                    d.printf("GPS: OFF (no location yet)\n");
                } else {
                    double lat = 0.0, lon = 0.0;
                    LocationManager::getHomeLocation(lat, lon);
                    const char* srcLabel =
                        (LocationManager::currentSource() == LocationManager::Source::Manual)
                            ? "manual" : "IP";
                    d.printf("GPS: OFF (%s: %.2f,%.2f)\n", srcLabel, lat, lon);
                }
                break;
            case Item::DisplayBrightness:
                d.printf("Display Brightness: %d%%\n", displayBrightnessPercent);
                break;
            case Item::LedBrightness:
                d.printf("LED Brightness: %d%%\n", NeopixelStatus::getBrightnessPercent());
                break;
            case Item::Volume:
                d.printf("Volume: %d/10\n", VolumeControl::currentStep());
                break;
            default: break;
        }
    }

    d.setTextColor(TFT_DARKGREEN, TFT_BLACK);
    d.println("\n;/. move  ,// adjust");
    d.println(selected == Item::Location ? "Enter: toggle GPS  m: manual"
                                          : "Enter: open WiFi / toggle GPS");

    d.pushSprite(0, 0);
}

}
