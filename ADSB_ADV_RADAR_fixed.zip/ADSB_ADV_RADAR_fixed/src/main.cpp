#include <M5Cardputer.h>
#include "config.h"
#include "screen_mode.h"
#include "wifi_manager.h"
#include "adsb_client.h"
#include "aircraft_table.h"
#include "display_radar.h"
#include "proximity_alert.h"
#include "sd_storage.h"
#include "airline_lookup.h"
#include "neopixel_status.h"
#include "volume_control.h"
#include "wifi_setup_screen.h"
#include "settings_menu.h"
#include "location_manager.h"

namespace {
    uint32_t lastFetchMs = 0;
    uint32_t lastFrameMs = 0;
    uint8_t selectedIndex = 0;
    int lastHttpCode = 0;

    bool sdReady = false;
    bool timePrimed = false;

    ScreenMode screenMode = ScreenMode::Radar;

    const char* wifiStatusLabel() {
        switch (WifiMgr::getState()) {
            case WifiMgr::State::Connected:      return "WIFI";
            case WifiMgr::State::Connecting:      return "...";
            case WifiMgr::State::Failed:          return "FAIL";
            case WifiMgr::State::NoCredentials:   return "NOCFG";
            default:                               return "IDLE";
        }
    }

    const char* locationStatusLabel() {
        switch (LocationManager::currentSource()) {
            case LocationManager::Source::GpsFix:        return "GPS";
            case LocationManager::Source::IpGeolocation: return "IP";
            case LocationManager::Source::Manual:        return "MANUAL";
            case LocationManager::Source::Persisted:     return "SAVED";
            default:                                      return "NOLOC";
        }
    }

    constexpr uint8_t HID_BACKSPACE = 0x2A;

    void handleKeyboardRadar(const Keyboard_Class::KeysState& status) {
        for (auto k : status.hid_keys) {
            if (k == HID_BACKSPACE) {
                screenMode = ScreenMode::Settings;
                SettingsMenu::onEnter();
                return;
            }
        }
        for (auto c : status.word) {
            if (status.fn) {
                if (c == 'w') {
                    screenMode = ScreenMode::Settings;
                    SettingsMenu::onEnter();
                    return;
                }
                if (c == '=') { VolumeControl::increase(); continue; }
                if (c == '-') { VolumeControl::decrease(); continue; }
            } else if (c == ' ') {
                DisplayRadar::cycleRange();
            }
        }

        if (status.tab) {
            uint8_t count = AircraftTable::validCount();
            if (count > 0) selectedIndex = (selectedIndex + 1) % count;
        }
    }
}

void setup() {
    auto cfg = M5.config();
    M5Cardputer.begin(cfg, true);

    M5Cardputer.Display.setRotation(1);
    M5Cardputer.Display.setBrightness(80);

    DisplayRadar::init();
    AircraftTable::init();
    ProximityAlert::init();
    WifiMgr::init();
    AirlineLookup::init();
    NeopixelStatus::init();
    VolumeControl::init();
    WifiSetupScreen::init();
    SettingsMenu::init();
    LocationManager::init();

    sdReady = SdStorage::init();
    if (sdReady) {
        SdStorage::seedDefaultDataFiles();
    }
    // If SdStorage::init() fails, the radar still runs fine — airline/seat
    // fields just stay blank. Nothing else depends on the SD card being present.

    // "Kinectputer-style" SD credential loading
    if (WifiMgr::loadCredentialsFromSd()) {
        WifiMgr::beginConnect();
    } else if (WifiMgr::hasStoredCredentials()) {
        WifiMgr::beginConnect();
    }

    lastFrameMs = millis();
}

void loop() {
    M5Cardputer.update();

    bool keyChanged = M5Cardputer.Keyboard.isChange() && M5Cardputer.Keyboard.isPressed();
    Keyboard_Class::KeysState status;
    if (keyChanged) status = M5Cardputer.Keyboard.keysState();

    if (screenMode == ScreenMode::Radar) {
        if (keyChanged) handleKeyboardRadar(status);
    } else { // Settings
        if (keyChanged) {
            char chars[16];
            uint8_t charCount = 0;
            for (auto c : status.word) {
                if (charCount < sizeof(chars)) chars[charCount++] = c;
            }
            uint8_t hidKeys[16];
            uint8_t hidCount = 0;
            for (auto k : status.hid_keys) {
                if (hidCount < sizeof(hidKeys)) hidKeys[hidCount++] = k;
            }
            SettingsMenu::handleWord(chars, charCount, status.fn, status.shift,
                                       hidKeys, hidCount);
        }
        if (SettingsMenu::isDone()) {
            screenMode = ScreenMode::Radar;
        }
    }

    WifiMgr::update();
    LocationManager::update();

    if (WifiMgr::getState() == WifiMgr::State::Connected && !timePrimed) {
        AdsbClient::primeTime();
        timePrimed = true;
    }
    if (WifiMgr::getState() == WifiMgr::State::Connected) {
        LocationManager::requestIpLookupIfNeeded(); // one-shot, no-ops after first success/attempt
    }

    uint32_t now = millis();

    if (screenMode == ScreenMode::Radar &&
        WifiMgr::getState() == WifiMgr::State::Connected &&
        now - lastFetchMs >= Config::FETCH_INTERVAL_MS) {
        lastFetchMs = now;

        double homeLat = 0.0, homeLon = 0.0;
        if (LocationManager::currentSource() == LocationManager::Source::None) {
            return; // no GPS fix / IP geolocation / persisted location yet — wait for one
        }
        LocationManager::getHomeLocation(homeLat, homeLon);

        auto result = AdsbClient::fetch(homeLat, homeLon,
                                         DisplayRadar::currentRangeKm(),
                                         AircraftTable::raw(), AircraftTable::capacity());
        lastHttpCode = result.httpCode;

        if (result.ok) {
            AircraftTable::postFetchUpdate(homeLat, homeLon);

            if (selectedIndex >= AircraftTable::validCount()) selectedIndex = 0;

            NeopixelStatus::update(AircraftTable::raw(), AircraftTable::validCount(),
                                    AircraftTable::validCount() > 0 ? (int)selectedIndex : -1);
        }
    }

    NeopixelStatus::tick(now);
    if (NeopixelStatus::isFlashRisingEdge()) {
        ProximityAlert::beepOnce();
    }

    if (screenMode == ScreenMode::Radar) {
        uint32_t deltaMs = now - lastFrameMs;
        DisplayRadar::tickSweep(deltaMs);

        DisplayRadar::render(AircraftTable::raw(), AircraftTable::validCount(),
                              DisplayRadar::currentRangeKm(), selectedIndex,
                              wifiStatusLabel(), M5Cardputer.Power.getBatteryLevel(),
                              locationStatusLabel(), lastHttpCode);
    } else {
        SettingsMenu::render();
    }
    lastFrameMs = now;

    delay(16);
}
