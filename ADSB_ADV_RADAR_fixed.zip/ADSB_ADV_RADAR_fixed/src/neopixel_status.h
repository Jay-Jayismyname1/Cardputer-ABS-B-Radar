#pragma once
#include <Arduino.h>
#include "aircraft.h"

namespace NeopixelStatus {
    void init();
    void update(const Aircraft* table, uint8_t count, int selectedIndex = -1);
    void tick(uint32_t now);
    bool isFlashRisingEdge();
    void setBrightnessPercent(uint8_t percent);
    uint8_t getBrightnessPercent();
    void setOff();
}
